/*--------------------------------------------------------------------------------------------------
Made by: Alberto Bobadilla
on: 2017/06/02
--------------------------------------------------------------------------------------------------*/
#ifndef __LIGHT_H_
#define __LIGHT_H_
#include <iostream>
#include "Vector3.h"
class Light
{
public:
	Vector3<float> m_v3Position;
	Light();
	Light(Light const& other);
	Light& operator=(Light const& other);
	~Light();
	friend std::ostream* operator<<(std::ostream& os, Light other)
	{
		os << other.m_v3Position;
		return &os;
	}
};

#endif //__LIGHT_H_