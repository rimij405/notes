#include "Main.h"
int main(void)
{
	LightManager* pLightMngr = nullptr;
	pLightMngr = LightManager::GetInstance();
	for (uint i = 0; i < 10; ++i)
	{
		Light* pLight = new Light();
		pLight->m_v3Position.x = i;
		pLight->m_v3Position.y = i;
		pLight->m_v3Position.z = i;
		pLightMngr->AddLight(pLight);
	}

	Scene myScene;
	std::cout << std::endl;
	getchar();
	LightManager::ReleaseInstance();
}