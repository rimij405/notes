/*--------------------------------------------------------------------------------------------------
Made by: Alberto Bobadilla
on: 2017/06/02
--------------------------------------------------------------------------------------------------*/
#ifndef __SCENE_H_
#define __SCENE_H_
#include <iostream>
#include "LightManager.h"

class Scene
{
	LightManager* m_pLightMngr = nullptr;
public:
	Scene();
	Scene(Scene const& other);
	Scene& operator=(Scene const& other);
	~Scene();
	friend std::ostream* operator<<(std::ostream& os, Scene other)
	{
		return &os;
	}
	void Init(void);
	void Release(void);
};

#endif //__SCENE_H_