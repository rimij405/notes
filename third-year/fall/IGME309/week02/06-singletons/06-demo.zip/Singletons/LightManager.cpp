#include "LightManager.h"
LightManager* LightManager::m_pInstance = nullptr;
LightManager::LightManager()
{
	Init();
}
LightManager::LightManager(LightManager const& other){}
LightManager& LightManager::operator=(LightManager const& other){ return *this; }
LightManager::~LightManager()
{
	Release();
}
LightManager* LightManager::GetInstance(void)
{
	if (m_pInstance == nullptr)
	{
		m_pInstance = new LightManager();
	}
	return m_pInstance;
}
void LightManager::ReleaseInstance(void)
{
	if (m_pInstance != nullptr)
	{
		delete m_pInstance;
		m_pInstance = nullptr;
	}
}
void LightManager::Init(void)
{

}
void LightManager::Release(void)
{
	uint uCount = m_lightList.size();
	for (uint i = 0; i < uCount; ++i)
	{
		if (m_lightList[i] != nullptr)
		{
			delete m_lightList[i];
			m_lightList[i] = nullptr;
		}
	}
	m_lightList.clear();
}
void LightManager::AddLight(Light* a_pLight)
{
	if (a_pLight == nullptr)
		return;
	m_lightList.push_back(a_pLight);
}