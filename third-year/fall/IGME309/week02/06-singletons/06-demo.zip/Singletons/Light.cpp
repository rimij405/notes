#include "Light.h"
Light::Light()
{
	m_v3Position = Vector3<float>(0.0f,0.0f,0.0f);
}
Light::Light(Light const& other)
{
	m_v3Position = other.m_v3Position;
}
Light& Light::operator=(Light const& other)
{
	if (this != &other)
	{
		m_v3Position = other.m_v3Position;
	}
	return *this;
}
Light::~Light()
{

}
