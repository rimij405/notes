#include "Scene.h"
Scene::Scene()
{
	Init();
}
Scene::Scene(Scene const& other)
{
	
}
Scene& Scene::operator=(Scene const& other)
{
	if (this != &other)
	{
		
	}
	return *this;
}
Scene::~Scene()
{
	Release();
}
void Scene::Init(void)
{
	m_pLightMngr = LightManager::GetInstance();
}
void Scene::Release(void)
{

}

