/*--------------------------------------------------------------------------------------------------
Made by: Alberto Bobadilla
on: 2017/06/02
--------------------------------------------------------------------------------------------------*/
#ifndef __FOO_H_
#define __FOO_H_
#include <iostream>

class Foo
{
public:
	Foo();
	Foo(Foo const& other);
	Foo& operator=(Foo const& other);
	~Foo();
	int var = 0;
	friend std::ostream* operator<<(std::ostream& os, Foo other)
	{
		os << other.var;
		return &os;
	}
}; 

#endif //__FOO_H_