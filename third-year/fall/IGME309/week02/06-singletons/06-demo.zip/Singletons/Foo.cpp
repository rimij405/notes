#include "Foo.h"
Foo::Foo()
{
	var = 0;
}
Foo::Foo(Foo const& other)
{
	var = other.var;
}
Foo& Foo::operator=(Foo const& other)
{
	if (this != &other)
	{
		var = other.var;
	}
	return *this;
}
Foo::~Foo()
{

}
