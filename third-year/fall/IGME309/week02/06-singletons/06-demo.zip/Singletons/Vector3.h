/*--------------------------------------------------------------------------------------------------
Made by: Alberto Bobadilla
on: 2017/06/02
--------------------------------------------------------------------------------------------------*/
#ifndef __VECTOR3_H_
#define __VECTOR3_H_
#include <iostream>

template <class T>
class Vector3
{
public:
	T x;
	T y;
	T z;
	Vector3(){};
	Vector3(T a_x, T a_y, T a_z):x(a_x), y(a_y), z(a_z){};
	Vector3(Vector3 const& other)
	{
		x = other.x;
		y = other.y;
		z = other.z;
	};
	Vector3& operator=(Vector3 const& other)
	{
		if (this != &other)
		{
			x = other.x;
			y = other.y;
			z = other.z;
		}
		return *this;
	};
	~Vector3() {};
	friend std::ostream* operator<<(std::ostream& os, Vector3 other)
	{
		os << "( ";
		os << other.x;
		os << " , ";
		os << other.y;
		os << " , ";
		os << other.z;
		os << " )";
		return &os;
	}
};

#endif //__VECTOR3_H_