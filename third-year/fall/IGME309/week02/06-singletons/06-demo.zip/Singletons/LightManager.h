/*--------------------------------------------------------------------------------------------------
Made by: Alberto Bobadilla
on: 2017/06/02
--------------------------------------------------------------------------------------------------*/
#ifndef __LIGHTMANAGER_H_
#define __LIGHTMANAGER_H_
#include <iostream>
#include <vector>
#include "Light.h"
#define uint unsigned int

class LightManager
{
	LightManager();
	LightManager(LightManager const& other);
	LightManager& operator=(LightManager const& other);
	~LightManager();
	void Init(void);
	void Release(void);
	static LightManager* m_pInstance;
	std::vector<Light*> m_lightList;
public:
	void AddLight(Light* a_pLight);
	static LightManager* GetInstance(void);
	static void ReleaseInstance(void);
	friend std::ostream* operator<<(std::ostream& os, LightManager other)
	{
		//os << other.m_nTest;
		return &os;
	}
};

#endif //__LIGHTMANAGER_H_